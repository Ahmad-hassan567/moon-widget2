import math
from datetime import date
R=math.radians; D=math.degrees
def sunset_hour(d, lat=24.8607, lon=67.0011, tz=5.0):
    """Local sunset (hours, Asia/Karachi) via NOAA algorithm. Returns None if no sunset."""
    jd=d.toordinal()+1721424.5+0.5  # noon UT approx
    # refine using local solar noon
    def calc(jdv):
        t=(jdv-2451545.0)/36525.0
        l0=(280.46646+t*(36000.76983+t*0.0003032))%360
        m=357.52911+t*(35999.05029-0.0001537*t)
        e=0.016708634-t*(0.000042037+0.0000001267*t)
        c=math.sin(R(m))*(1.914602-t*(0.004817+0.000014*t))+math.sin(R(2*m))*(0.019993-0.000101*t)+math.sin(R(3*m))*0.000289
        tl=l0+c
        om=125.04-1934.136*t
        app=tl-0.00569-0.00478*math.sin(R(om))
        sec=21.448-t*(46.815+t*(0.00059-t*0.001813))
        obl0=23+(26+sec/60)/60
        obl=obl0+0.00256*math.cos(R(om))
        dec=D(math.asin(math.sin(R(obl))*math.sin(R(app))))
        y=math.tan(R(obl/2))**2
        eq=4*D(y*math.sin(2*R(l0))-2*e*math.sin(R(m))+4*e*y*math.sin(R(m))*math.cos(2*R(l0))-0.5*y*y*math.sin(4*R(l0))-1.25*e*e*math.sin(2*R(m)))
        return dec,eq
    jd0=d.toordinal()+1721424.5  # 0h UT of date
    # first pass at ~ local noon-evening
    est=0.5+(-lon/360.0)+0.25
    dec,eq=calc(jd0+0.5-tz/24)
    cosha=(math.cos(R(90.833))/(math.cos(R(lat))*math.cos(R(dec)))-math.tan(R(lat))*math.tan(R(dec)))
    if cosha>1 or cosha<-1: return None
    ha=D(math.acos(cosha))
    ss_utc_min=720-4*(lon-ha)-eq
    # second pass at computed time
    dec,eq=calc(jd0+ss_utc_min/1440.0)
    cosha=(math.cos(R(90.833))/(math.cos(R(lat))*math.cos(R(dec)))-math.tan(R(lat))*math.tan(R(dec)))
    ha=D(math.acos(cosha))
    ss_utc_min=720-4*(lon-ha)-eq
    return (ss_utc_min/60.0+tz)%24
if __name__=="__main__":
    for dd in [date(2026,1,1),date(2026,3,21),date(2026,6,21),date(2026,9,23),date(2026,11,3),date(2026,12,1),date(2026,12,21)]:
        h=sunset_hour(dd); print(dd, f"{int(h)}:{int(round((h%1)*60)):02d}")
