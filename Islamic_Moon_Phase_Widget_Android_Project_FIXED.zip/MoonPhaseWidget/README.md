# Islamic Moon Phase Widget (Android)

Compact 2×2 home-screen widget: dark-navy starry background, one of six moon artworks, the Hijri date
and the moon-phase name underneath. Fully offline (no INTERNET permission). Android 8.0+ (API 26+),
including Android 10.

> **Status:** the source was corrected and completed and its core maths was verified numerically
> (see "Verification"), but it has **not been compiled** by the author's tooling (no Android SDK/Gradle
> was available). Build it once in Android Studio; see below.

## Build the APK
**Android Studio (easiest):** open the `MoonPhaseWidget` folder, let Gradle sync (it downloads Gradle 8.9,
needs Android SDK Platform 35 — Studio offers to install it), then **Build > Build APK(s)**.
APK: `app/build/outputs/apk/debug/app-debug.apk`

**Command line** (JDK 17+, Android SDK installed, `ANDROID_HOME` set):
```
gradle wrapper --gradle-version 8.9     # once; creates gradlew + gradle-wrapper.jar
./gradlew test                           # runs the unit tests (astronomy, sunset, Hijri rollover)
./gradlew assembleDebug
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

## Use
1. Open **Moon Phase**, tap one of the six artworks, set the Pakistan adjustment.
2. Tap **Add widget to home screen** (or long-press the home screen > Widgets > *Islamic Moon*).
3. Tap the widget any time to reopen the settings.

## How it works
- **Moon phase:** Meeus' lunar-longitude series (58 terms) minus the Sun's longitude gives the real
  elongation at the current instant. Illuminated fraction = (1 − cos E)/2; E < 180° = waxing.
- **Artwork:** lit shape = half-circle limb + half-ellipse terminator, so the picture always matches
  the true illuminated fraction (crescent, quarter, gibbous, full, waxing and waning).
- **Hijri date:** Android's built-in Umm al-Qura calendar. After today's Karachi sunset (NOAA algorithm,
  Karachi coordinates, always Asia/Karachi time regardless of the phone's zone) the next day's Hijri date
  is shown. Then the **−1 / 0 / +1** Pakistan adjustment is applied.
- **Refresh:** an alarm fires at the next Karachi sunset (or hourly, whichever is sooner), plus system
  time/zone/date-change and boot/update broadcasts. On Android 12+ alarms are inexact and can be a few
  minutes late.

## Verification done
- Moon elongation vs. known events (new moons 2017-08-21, 2019-07-02, 2024-04-08, 2026-08-12; full moons
  2024-04-23, 2025-09-07, 2026-03-03): all within 0.006° (< 1 minute). Meeus example 47.a reproduced.
- Terminator geometry vs. a 3D sphere-lighting model for every 15° of the cycle: ≤ 0.4 % pixel mismatch.
- Karachi sunset: ≈17:50 on 3 Nov 2026, ≈19:24 at the June solstice. Hijri conversions match Umm al-Qura.
- Scripts in `tools/verify/`; JUnit tests in `app/src/test/`.

## Things to know
- Umm al-Qura (Saudi) often differs from Pakistan's Ruet-e-Hilal by one day. The default is **No change**;
  choose **−1 day** when Pakistan is a day behind.
- The phase is astronomical, not a visibility/sighting forecast.
- Sunset is the geometric sunset, not a published Maghrib timetable (differences of a few minutes).
