package com.example.moonphasewidget

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate
import java.time.ZoneOffset
import java.time.ZonedDateTime

class WidgetLogicTest {

    private fun utcMillis(y: Int, mo: Int, d: Int, h: Int, mi: Int): Long =
        ZonedDateTime.of(y, mo, d, h, mi, 0, 0, ZoneOffset.UTC).toInstant().toEpochMilli()

    private fun karachi(y: Int, mo: Int, d: Int, h: Int, mi: Int): ZonedDateTime =
        ZonedDateTime.of(y, mo, d, h, mi, 0, 0, HijriCalc.KARACHI)

    // ---- astronomy: known conjunction / opposition instants ----

    private fun angularDiff(a: Double, b: Double): Double = ((a - b + 540.0) % 360.0) - 180.0

    @Test fun newMoonInstantsHaveZeroElongation() {
        val events = listOf(
            utcMillis(2024, 4, 8, 18, 21), utcMillis(2017, 8, 21, 18, 30),
            utcMillis(2019, 7, 2, 19, 16), utcMillis(2026, 8, 12, 17, 37)
        )
        for (t in events) {
            val e = MoonMath.elongation(t)
            assertTrue("elongation $e", Math.abs(angularDiff(e, 0.0)) < 0.05)
        }
    }

    @Test fun fullMoonInstantsHave180Elongation() {
        val events = listOf(
            utcMillis(2024, 4, 23, 23, 49), utcMillis(2025, 9, 7, 18, 9), utcMillis(2026, 3, 3, 11, 38)
        )
        for (t in events) {
            val e = MoonMath.elongation(t)
            assertTrue("elongation $e", Math.abs(angularDiff(e, 180.0)) < 0.05)
        }
    }

    @Test fun phaseNamesAndWaxing() {
        val full = MoonMath.state(utcMillis(2024, 4, 23, 23, 49))
        assertEquals("Full Moon", full.name)
        assertTrue(full.illumination > 0.999)
        val newMoon = MoonMath.state(utcMillis(2024, 4, 8, 18, 21))
        assertEquals("New Moon", newMoon.name)
        assertTrue(newMoon.illumination < 0.001)
        // about a week after new moon -> first quarter, waxing, ~50% lit
        val fq = MoonMath.state(utcMillis(2024, 4, 15, 19, 13))
        assertEquals("First Quarter", fq.name)
        assertTrue(fq.waxing)
        assertEquals(0.5, fq.illumination, 0.02)
        // 3 days after full -> waning gibbous
        val wg = MoonMath.state(utcMillis(2024, 4, 27, 0, 0))
        assertEquals("Waning Gibbous", wg.name)
        assertTrue(!wg.waxing)
    }

    // ---- sunset ----

    @Test fun karachiSunsetIsPlausible() {
        val nov = SunsetTime.sunsetHour(LocalDate.of(2026, 11, 3))
        assertTrue("Nov sunset $nov", nov in 17.75..17.90)      // ~17:50
        val jun = SunsetTime.sunsetHour(LocalDate.of(2026, 6, 21))
        assertTrue("Jun sunset $jun", jun in 19.33..19.50)      // ~19:24
        val dec = SunsetTime.sunsetHour(LocalDate.of(2026, 12, 1))
        assertTrue("Dec sunset $dec", dec in 17.60..17.80)
    }

    // ---- Hijri rollover and adjustment ----

    @Test fun hijriDateRollsOverAtKarachiSunset() {
        val before = HijriCalc.effectiveDate(karachi(2026, 11, 3, 17, 0), 0)
        val after = HijriCalc.effectiveDate(karachi(2026, 11, 3, 19, 0), 0)
        assertEquals(LocalDate.of(2026, 11, 3), before)
        assertEquals(LocalDate.of(2026, 11, 4), after)
        val justBefore = HijriCalc.effectiveDate(karachi(2026, 11, 3, 17, 45), 0)
        val justAfter = HijriCalc.effectiveDate(karachi(2026, 11, 3, 17, 56), 0)
        assertEquals(LocalDate.of(2026, 11, 3), justBefore)
        assertEquals(LocalDate.of(2026, 11, 4), justAfter)
    }

    @Test fun rolloverIgnoresDeviceTimeZone() {
        // 13:00 UTC = 18:00 Karachi (after sunset) regardless of where the phone is.
        val utc = ZonedDateTime.of(2026, 11, 3, 13, 0, 0, 0, ZoneOffset.UTC)
        assertEquals(LocalDate.of(2026, 11, 4), HijriCalc.effectiveDate(utc, 0))
    }

    @Test fun pakistanAdjustmentShiftsByOneDay() {
        val t = karachi(2026, 11, 3, 10, 0)
        assertEquals(LocalDate.of(2026, 11, 2), HijriCalc.effectiveDate(t, -1))
        assertEquals(LocalDate.of(2026, 11, 3), HijriCalc.effectiveDate(t, 0))
        assertEquals(LocalDate.of(2026, 11, 4), HijriCalc.effectiveDate(t, 1))
        // out-of-range values are clamped to +/-1
        assertEquals(LocalDate.of(2026, 11, 4), HijriCalc.effectiveDate(t, 5))
    }

    @Test fun hijriConversionMatchesUmmAlQura() {
        assertEquals(HijriDay(1, 10, 1445), HijriCalc.hijriFor(LocalDate.of(2024, 4, 10)))   // 1 Shawwal 1445
        assertEquals(HijriDay(1, 9, 1447), HijriCalc.hijriFor(LocalDate.of(2026, 2, 18)))    // 1 Ramadan 1447
        assertEquals("23 Jumada I 1448", HijriCalc.hijriFor(LocalDate.of(2026, 11, 3)).text)
    }

    @Test fun nextSunsetIsInTheFuture() {
        val morning = karachi(2026, 11, 3, 9, 0)
        val evening = karachi(2026, 11, 3, 20, 0)
        val m = HijriCalc.nextSunsetMillis(morning)
        val e = HijriCalc.nextSunsetMillis(evening)
        assertTrue(m > morning.toInstant().toEpochMilli())
        assertTrue(m < karachi(2026, 11, 3, 18, 30).toInstant().toEpochMilli())
        assertTrue(e > evening.toInstant().toEpochMilli())
        assertTrue(e > karachi(2026, 11, 4, 17, 0).toInstant().toEpochMilli())
    }
}
