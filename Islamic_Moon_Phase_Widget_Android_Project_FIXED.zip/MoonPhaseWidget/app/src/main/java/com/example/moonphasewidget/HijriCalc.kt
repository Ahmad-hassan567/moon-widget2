package com.example.moonphasewidget

import java.time.LocalDate
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.chrono.HijrahChronology
import java.time.temporal.ChronoField

/** Hijri day with the rollover and adjustment rules this widget uses. */
data class HijriDay(val day: Int, val month: Int, val year: Int) {
    val monthName: String get() = HijriCalc.MONTH_NAMES[(month - 1).coerceIn(0, 11)]
    val text: String get() = "$day $monthName $year"
}

object HijriCalc {
    val KARACHI: ZoneId = ZoneId.of("Asia/Karachi")

    val MONTH_NAMES = arrayOf(
        "Muharram", "Safar", "Rabi I", "Rabi II", "Jumada I", "Jumada II",
        "Rajab", "Shaban", "Ramadan", "Shawwal", "Dhul Qadah", "Dhul Hijjah"
    )

    /**
     * The civil (Gregorian) date whose Hijri equivalent should be shown:
     *  - after Karachi sunset the next civil date is used (Islamic day starts at sunset),
     *  - then the user's Pakistan adjustment (-1, 0, +1 day) is applied.
     */
    fun effectiveDate(now: ZonedDateTime, adjustmentDays: Int): LocalDate {
        val karachi = now.withZoneSameInstant(KARACHI)
        val today = karachi.toLocalDate()
        val hours = karachi.hour + karachi.minute / 60.0 + karachi.second / 3600.0
        val afterSunset = hours >= SunsetTime.sunsetHour(today)
        val civil = if (afterSunset) today.plusDays(1) else today
        return civil.plusDays(adjustmentDays.coerceIn(-1, 1).toLong())
    }

    fun hijriFor(date: LocalDate): HijriDay {
        val h = HijrahChronology.INSTANCE.date(date)   // Umm al-Qura calendar, built in, offline
        return HijriDay(
            day = h.get(ChronoField.DAY_OF_MONTH),
            month = h.get(ChronoField.MONTH_OF_YEAR),
            year = h.get(ChronoField.YEAR_OF_ERA)
        )
    }

    fun current(now: ZonedDateTime, adjustmentDays: Int): HijriDay =
        hijriFor(effectiveDate(now, adjustmentDays))

    /** Next moment (epoch millis) at which the displayed Hijri date will change: today's or tomorrow's Karachi sunset. */
    fun nextSunsetMillis(now: ZonedDateTime): Long {
        val karachi = now.withZoneSameInstant(KARACHI)
        var day = karachi.toLocalDate()
        var sunset = sunsetAt(day)
        if (!sunset.isAfter(karachi)) {
            day = day.plusDays(1)
            sunset = sunsetAt(day)
        }
        return sunset.toInstant().toEpochMilli()
    }

    fun sunsetAt(day: LocalDate): ZonedDateTime {
        val hour = SunsetTime.sunsetHour(day)
        val seconds = Math.round(hour * 3600.0)
        return day.atStartOfDay(KARACHI).plusSeconds(seconds)
    }
}
