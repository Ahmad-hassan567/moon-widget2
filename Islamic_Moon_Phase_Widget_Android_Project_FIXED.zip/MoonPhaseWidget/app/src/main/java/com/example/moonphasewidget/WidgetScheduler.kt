package com.example.moonphasewidget

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Build
import java.time.ZonedDateTime

/**
 * Keeps the widget fresh without internet: one alarm that fires at the next Karachi sunset
 * (when the Hijri date rolls over) or in one hour, whichever comes first. Each firing re-arms the next.
 */
object WidgetScheduler {
    const val ACTION_REFRESH = "com.example.moonphasewidget.ACTION_REFRESH"
    private const val REQUEST_CODE = 4711
    private const val SUNSET_GRACE_MS = 30_000L
    private const val MAX_INTERVAL_MS = 60L * 60L * 1000L

    private fun pendingIntent(context: Context): PendingIntent {
        val intent = Intent(context, MoonWidgetProvider::class.java).setAction(ACTION_REFRESH)
        return PendingIntent.getBroadcast(
            context, REQUEST_CODE, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    fun schedule(context: Context) {
        val manager = AppWidgetManager.getInstance(context)
        val ids = manager.getAppWidgetIds(ComponentName(context, MoonWidgetProvider::class.java))
        if (ids.isEmpty()) {
            cancel(context)
            return
        }
        val alarms = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val now = ZonedDateTime.now(HijriCalc.KARACHI)
        val nowMs = now.toInstant().toEpochMilli()
        val triggerAt = minOf(HijriCalc.nextSunsetMillis(now) + SUNSET_GRACE_MS, nowMs + MAX_INTERVAL_MS)
        val pi = pendingIntent(context)
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) {
            // Android 6-11 (including Android 10): exact alarms need no special permission.
            alarms.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi)
        } else {
            // Android 12+ restricts exact alarms; an inexact idle-friendly alarm is plenty for a widget.
            alarms.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi)
        }
    }

    fun cancel(context: Context) {
        val alarms = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        alarms.cancel(pendingIntent(context))
    }
}
