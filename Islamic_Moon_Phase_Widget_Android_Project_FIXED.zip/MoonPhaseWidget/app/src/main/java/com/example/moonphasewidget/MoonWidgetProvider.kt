package com.example.moonphasewidget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import java.time.ZonedDateTime
import java.util.Locale

class MoonWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        manager.updateAppWidget(ids, buildViews(context))
        WidgetScheduler.schedule(context)
    }

    override fun onEnabled(context: Context) {
        WidgetScheduler.schedule(context)
    }

    override fun onDisabled(context: Context) {
        WidgetScheduler.cancel(context)
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        when (intent.action) {
            WidgetScheduler.ACTION_REFRESH,
            Intent.ACTION_DATE_CHANGED,
            Intent.ACTION_TIME_CHANGED,
            Intent.ACTION_TIMEZONE_CHANGED,
            Intent.ACTION_BOOT_COMPLETED,
            Intent.ACTION_MY_PACKAGE_REPLACED -> {
                updateAll(context)
                WidgetScheduler.schedule(context)
            }
        }
    }

    companion object {
        /** Redraws every placed widget (used after a setting changes and by the alarm). */
        fun updateAll(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(ComponentName(context, MoonWidgetProvider::class.java))
            if (ids.isEmpty()) return
            manager.updateAppWidget(ids, buildViews(context))
        }

        /** Builds the widget UI for "now". Also used (clickable = false) for the in-app preview. */
        fun buildViews(context: Context, clickable: Boolean = true): RemoteViews {
            val style = Prefs.style(context)
            val adjustment = Prefs.adjustment(context)
            val now = ZonedDateTime.now(HijriCalc.KARACHI)
            val moon = MoonMath.state(now.toInstant().toEpochMilli())   // real phase at this instant
            val hijri = HijriCalc.current(now, adjustment)             // sunset rollover + Pakistan adjustment

            val views = RemoteViews(context.packageName, R.layout.moon_widget)
            views.setImageViewBitmap(R.id.stars_image, MoonRenderer.renderStars(360, 360))
            views.setImageViewBitmap(R.id.moon_image, MoonRenderer.render(moon.illumination, moon.waxing, style, 240))
            views.setTextViewText(R.id.hijri_date, hijri.text)
            views.setTextViewText(R.id.phase_name, moon.name)
            val percent = Math.round(moon.illumination * 100.0).toInt()
            views.setContentDescription(
                R.id.moon_image,
                String.format(Locale.US, "%s, %d%% illuminated", moon.name, percent)
            )
            if (clickable) {
                val open = PendingIntent.getActivity(
                    context, 0, Intent(context, MainActivity::class.java),
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                views.setOnClickPendingIntent(R.id.widget_root, open)
            }
            return views
        }
    }
}
