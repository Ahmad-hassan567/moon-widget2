package com.example.moonphasewidget

import android.content.Context

/** Tiny wrapper around SharedPreferences (all settings are local, nothing leaves the device). */
object Prefs {
    private const val FILE = "moon_prefs"
    private const val KEY_STYLE = "style"
    private const val KEY_ADJUST = "offset"   // key kept from the original project

    private fun sp(context: Context) = context.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun style(context: Context): Int =
        sp(context).getInt(KEY_STYLE, 0).coerceIn(0, MoonRenderer.styleNames.lastIndex)

    fun setStyle(context: Context, value: Int) {
        sp(context).edit().putInt(KEY_STYLE, value).apply()
    }

    /** Pakistan moon-sighting adjustment in days: -1, 0 or +1. */
    fun adjustment(context: Context): Int = sp(context).getInt(KEY_ADJUST, 0).coerceIn(-1, 1)

    fun setAdjustment(context: Context, value: Int) {
        sp(context).edit().putInt(KEY_ADJUST, value.coerceIn(-1, 1)).apply()
    }
}
