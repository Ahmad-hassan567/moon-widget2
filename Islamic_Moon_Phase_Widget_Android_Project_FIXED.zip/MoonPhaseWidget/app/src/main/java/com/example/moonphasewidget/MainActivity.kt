package com.example.moonphasewidget

import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

/** Settings screen: pick one of six moon styles, set the Pakistan Hijri adjustment, add the widget. */
class MainActivity : Activity() {

    private val navy = Color.rgb(11, 18, 32)
    private val textMain = 0xFFF4EFFF.toInt()
    private val textDim = 0xFFAAB8D0.toInt()
    private val gold = 0xFFFFD36B.toInt()
    private val outline = 0xFF26334A.toInt()

    private var density = 1f
    private lateinit var previewHolder: FrameLayout
    private lateinit var infoText: TextView
    private val thumbFrames = ArrayList<FrameLayout>()

    private fun dp(v: Int): Int = (v * density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        density = resources.displayMetrics.density
        window.setBackgroundDrawable(ColorDrawable(navy))

        val moon = MoonMath.state(System.currentTimeMillis())
        val stars = MoonRenderer.renderStars(360, 360)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(20), dp(20), dp(20), dp(28))
        }

        root.addView(label("\uD83C\uDF19  Islamic Moon", 25f, textMain, bold = true).apply { gravity = Gravity.CENTER })
        root.addView(label("Live preview of your 2\u00D72 widget", 13f, textDim).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(4), 0, dp(12))
        })

        previewHolder = FrameLayout(this)
        root.addView(previewHolder, LinearLayout.LayoutParams(dp(170), dp(170)).apply {
            gravity = Gravity.CENTER_HORIZONTAL
        })

        // ---- style picker ----
        root.addView(label("Moon artwork", 15f, textMain, bold = true).apply { setPadding(0, dp(20), 0, dp(8)) })
        val names = MoonRenderer.styleNames
        var row: LinearLayout? = null
        for (i in names.indices) {
            if (i % 3 == 0) {
                row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                root.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            }
            val cell = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                setPadding(0, dp(4), 0, dp(8))
            }
            val frame = FrameLayout(this)
            val starView = ImageView(this).apply {
                scaleType = ImageView.ScaleType.CENTER_CROP
                setImageBitmap(stars)
            }
            val moonView = ImageView(this).apply {
                scaleType = ImageView.ScaleType.FIT_CENTER
                setImageBitmap(MoonRenderer.render(moon.illumination, moon.waxing, i, 200))
                setPadding(dp(4), dp(4), dp(4), dp(4))
            }
            frame.addView(starView, FrameLayout.LayoutParams(-1, -1))
            frame.addView(moonView, FrameLayout.LayoutParams(-1, -1))
            frame.setOnClickListener {
                Prefs.setStyle(this, i)
                onSettingsChanged()
            }
            thumbFrames.add(frame)
            cell.addView(frame, LinearLayout.LayoutParams(dp(92), dp(92)))
            cell.addView(label(names[i], 11f, textDim).apply {
                gravity = Gravity.CENTER
                setPadding(0, dp(4), 0, 0)
            })
            row!!.addView(cell, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        }

        // ---- Pakistan Hijri adjustment ----
        root.addView(label("Pakistan Hijri adjustment", 15f, textMain, bold = true).apply {
            setPadding(0, dp(16), 0, dp(4))
        })
        root.addView(label(
            "Pakistan often starts a month a day later than the Umm al-Qura calendar used here. " +
                "Shift the date by one day to match the Ruet-e-Hilal announcement.",
            12f, textDim
        ).apply { setPadding(0, 0, 0, dp(6)) })

        val idMinus = View.generateViewId()
        val idZero = View.generateViewId()
        val idPlus = View.generateViewId()
        val group = RadioGroup(this).apply { orientation = RadioGroup.HORIZONTAL }
        fun radio(id: Int, text: String) = RadioButton(this).apply {
            this.id = id
            this.text = text
            setTextColor(textMain)
        }
        group.addView(radio(idMinus, "\u22121 day"), RadioGroup.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        group.addView(radio(idZero, "No change"), RadioGroup.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        group.addView(radio(idPlus, "+1 day"), RadioGroup.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        group.check(
            when (Prefs.adjustment(this)) {
                -1 -> idMinus
                1 -> idPlus
                else -> idZero
            }
        )
        group.setOnCheckedChangeListener { _, checkedId ->
            val value = when (checkedId) {
                idMinus -> -1
                idPlus -> 1
                else -> 0
            }
            Prefs.setAdjustment(this, value)
            onSettingsChanged()
        }
        root.addView(group, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        // ---- live info ----
        infoText = label("", 12f, textDim).apply { setPadding(0, dp(16), 0, dp(12)) }
        root.addView(infoText)

        // ---- add widget ----
        val add = Button(this).apply {
            text = "Add widget to home screen"
            setOnClickListener { requestPin() }
        }
        root.addView(add, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(label(
            "Works fully offline. The Hijri date changes at Karachi sunset. " +
                "The moon phase is calculated astronomically, not from a sighting.",
            11f, textDim
        ).apply { setPadding(0, dp(12), 0, 0) })

        val scroll = ScrollView(this)
        scroll.fitsSystemWindows = true   // keeps content clear of the system bars on Android 15 edge-to-edge
        scroll.addView(root)
        setContentView(scroll)

        onSettingsChanged()
    }

    override fun onResume() {
        super.onResume()
        if (::previewHolder.isInitialized) onSettingsChanged()
    }

    private fun onSettingsChanged() {
        refreshPreview()
        refreshThumbHighlight()
        refreshInfo()
        MoonWidgetProvider.updateAll(this)
        WidgetScheduler.schedule(this)
    }

    private fun refreshPreview() {
        previewHolder.removeAllViews()
        val view = MoonWidgetProvider.buildViews(this, clickable = false).apply(this, previewHolder)
        previewHolder.addView(view, FrameLayout.LayoutParams(-1, -1))
    }

    private fun refreshThumbHighlight() {
        val selected = Prefs.style(this)
        for (i in thumbFrames.indices) {
            val isSel = i == selected
            thumbFrames[i].background = GradientDrawable().apply {
                setColor(navy)
                cornerRadius = dp(14).toFloat()
                setStroke(dp(if (isSel) 3 else 1), if (isSel) gold else outline)
            }
        }
    }

    private fun refreshInfo() {
        val now = ZonedDateTime.now(HijriCalc.KARACHI)
        val hijri = HijriCalc.current(now, Prefs.adjustment(this))
        val moon = MoonMath.state(now.toInstant().toEpochMilli())
        val sunset = HijriCalc.sunsetAt(now.toLocalDate()).format(DateTimeFormatter.ofPattern("HH:mm"))
        val percent = Math.round(moon.illumination * 100.0).toInt()
        infoText.text = String.format(
            Locale.US,
            "Hijri date now: %s\nKarachi sunset today: %s (date advances then)\nMoon: %s, %d%% illuminated",
            hijri.text, sunset, moon.name, percent
        )
    }

    private fun requestPin() {
        val manager = AppWidgetManager.getInstance(this)
        val provider = ComponentName(this, MoonWidgetProvider::class.java)
        if (manager.isRequestPinAppWidgetSupported) {
            manager.requestPinAppWidget(provider, null, null)
        } else {
            Toast.makeText(
                this,
                "Long-press the home screen, open Widgets and choose Islamic Moon.",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    private fun label(text: String, size: Float, color: Int, bold: Boolean = false): TextView =
        TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }
}
