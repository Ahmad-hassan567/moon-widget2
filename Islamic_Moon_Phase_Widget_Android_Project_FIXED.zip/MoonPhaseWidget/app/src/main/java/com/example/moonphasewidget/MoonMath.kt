package com.example.moonphasewidget

import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.pow
import kotlin.math.sin

/** Snapshot of the Moon's phase at one instant. */
data class MoonState(
    /** Geocentric elongation Moon-Sun in ecliptic longitude, degrees 0..360 (0 = new, 180 = full). */
    val elongation: Double,
    /** Illuminated fraction of the disc, 0.0..1.0. */
    val illumination: Double,
    /** True while the Moon is waxing (northern-hemisphere view: right side lit). */
    val waxing: Boolean,
    val name: String
)

/**
 * Astronomical moon phase, computed offline from Jean Meeus, "Astronomical Algorithms" (ch. 47 lunar
 * longitude series, truncated to 58 terms) and a standard low-precision solar longitude.
 * Checked against known new/full moon instants: error is below 0.01 degree (< 1 minute of time).
 */
object MoonMath {
    private const val DELTA_T_SECONDS = 69.2

    /** Phase-name window around the four principal phases, in degrees of elongation (~12 hours each side). */
    private const val PRINCIPAL_WINDOW = 6.0

    // D, M, M', F multipliers and the longitude coefficient in 1e-6 degrees (Meeus Table 47.A).
    private val TERMS = arrayOf(
        intArrayOf(0, 0, 1, 0, 6288774), intArrayOf(2, 0, -1, 0, 1274027), intArrayOf(2, 0, 0, 0, 658314),
        intArrayOf(0, 0, 2, 0, 213618), intArrayOf(0, 1, 0, 0, -185116), intArrayOf(0, 0, 0, 2, -114332),
        intArrayOf(2, 0, -2, 0, 58793), intArrayOf(2, -1, -1, 0, 57066), intArrayOf(2, 0, 1, 0, 53322),
        intArrayOf(2, -1, 0, 0, 45758), intArrayOf(0, 1, -1, 0, -40923), intArrayOf(1, 0, 0, 0, -34720),
        intArrayOf(0, 1, 1, 0, -30383), intArrayOf(2, 0, 0, -2, 15327), intArrayOf(0, 0, 1, 2, -12528),
        intArrayOf(0, 0, 1, -2, 10980), intArrayOf(4, 0, -1, 0, 10675), intArrayOf(0, 0, 3, 0, 10034),
        intArrayOf(4, 0, -2, 0, 8548), intArrayOf(2, 1, -1, 0, -7888), intArrayOf(2, 1, 0, 0, -6766),
        intArrayOf(1, 0, -1, 0, -5163), intArrayOf(1, 1, 0, 0, 4987), intArrayOf(2, -1, 1, 0, 4036),
        intArrayOf(2, 0, 2, 0, 3994), intArrayOf(4, 0, 0, 0, 3861), intArrayOf(2, 0, -3, 0, 3665),
        intArrayOf(0, 1, -2, 0, -2689), intArrayOf(2, 0, -1, 2, -2602), intArrayOf(2, -1, -2, 0, 2390),
        intArrayOf(1, 0, 1, 0, -2348), intArrayOf(2, -2, 0, 0, 2236), intArrayOf(0, 1, 2, 0, -2120),
        intArrayOf(0, 2, 0, 0, -2069), intArrayOf(2, -2, -1, 0, 2048), intArrayOf(2, 0, 1, -2, -1773),
        intArrayOf(2, 0, 0, 2, -1595), intArrayOf(4, -1, -1, 0, 1215), intArrayOf(0, 0, 2, 2, -1110),
        intArrayOf(3, 0, -1, 0, -892), intArrayOf(2, 1, 1, 0, -810), intArrayOf(4, -1, -2, 0, 759),
        intArrayOf(0, 2, -1, 0, -713), intArrayOf(2, 2, -1, 0, -700), intArrayOf(2, 1, -2, 0, 691),
        intArrayOf(2, -1, 0, -2, 596), intArrayOf(4, 0, 1, 0, 549), intArrayOf(0, 0, 4, 0, 537),
        intArrayOf(4, -1, 0, 0, 520), intArrayOf(1, 0, -2, 0, -487), intArrayOf(2, 1, 0, -2, -399),
        intArrayOf(0, 0, 2, -2, -381), intArrayOf(1, 1, 1, 0, 351), intArrayOf(3, 0, -2, 0, -340),
        intArrayOf(4, 0, -3, 0, 330), intArrayOf(2, -1, 2, 0, 327), intArrayOf(0, 2, 1, 0, -323),
        intArrayOf(1, 1, -1, 0, 299), intArrayOf(2, 0, 3, 0, 294)
    )

    private fun norm360(x: Double): Double {
        val r = x % 360.0
        return if (r < 0.0) r + 360.0 else r
    }

    private fun rad(deg: Double): Double = Math.toRadians(deg)

    fun julianDay(epochMillis: Long): Double = epochMillis / 86_400_000.0 + 2440587.5

    /** Moon's ecliptic longitude in degrees for the given Julian Ephemeris Day. */
    fun moonLongitude(jde: Double): Double {
        val t = (jde - 2451545.0) / 36525.0
        val lp = norm360(218.3164477 + 481267.88123421 * t - 0.0015786 * t * t)
        val d = norm360(297.8501921 + 445267.1114034 * t - 0.0018819 * t * t)
        val m = norm360(357.5291092 + 35999.0502909 * t - 0.0001536 * t * t)
        val mp = norm360(134.9633964 + 477198.8675055 * t + 0.0087414 * t * t)
        val f = norm360(93.2720950 + 483202.0175233 * t - 0.0036539 * t * t)
        val ecc = 1.0 - 0.002516 * t - 0.0000074 * t * t
        var sum = 0.0
        for (term in TERMS) {
            val eFactor = ecc.pow(abs(term[1]))
            val arg = term[0] * d + term[1] * m + term[2] * mp + term[3] * f
            sum += term[4] * eFactor * sin(rad(arg))
        }
        val a1 = norm360(119.75 + 131.849 * t)
        val a2 = norm360(53.09 + 479264.290 * t)
        sum += 3958.0 * sin(rad(a1)) + 1962.0 * sin(rad(lp - f)) + 318.0 * sin(rad(a2))
        return norm360(lp + sum / 1.0e6)
    }

    /** Sun's apparent ecliptic longitude in degrees. */
    fun sunLongitude(jde: Double): Double {
        val t = (jde - 2451545.0) / 36525.0
        val l0 = norm360(280.46646 + 36000.76983 * t + 0.0003032 * t * t)
        val m = norm360(357.52911 + 35999.05029 * t - 0.0001537 * t * t)
        val c = (1.914602 - 0.004817 * t - 0.000014 * t * t) * sin(rad(m)) +
            (0.019993 - 0.000101 * t) * sin(rad(2.0 * m)) +
            0.000289 * sin(rad(3.0 * m))
        return norm360(l0 + c - 0.00569)
    }

    /** Elongation of the Moon from the Sun (degrees, 0..360) at an instant given in epoch milliseconds (UTC). */
    fun elongation(epochMillis: Long): Double {
        val jde = julianDay(epochMillis) + DELTA_T_SECONDS / 86_400.0
        return norm360(moonLongitude(jde) - sunLongitude(jde))
    }

    fun state(epochMillis: Long): MoonState {
        val e = elongation(epochMillis)
        val k = (1.0 - cos(rad(e))) / 2.0
        return MoonState(e, k, e < 180.0, nameFor(e))
    }

    fun nameFor(e: Double): String {
        val w = PRINCIPAL_WINDOW
        return when {
            e < w || e >= 360.0 - w -> "New Moon"
            e < 90.0 - w -> "Waxing Crescent"
            e < 90.0 + w -> "First Quarter"
            e < 180.0 - w -> "Waxing Gibbous"
            e < 180.0 + w -> "Full Moon"
            e < 270.0 - w -> "Waning Gibbous"
            e < 270.0 + w -> "Last Quarter"
            else -> "Waning Crescent"
        }
    }
}
