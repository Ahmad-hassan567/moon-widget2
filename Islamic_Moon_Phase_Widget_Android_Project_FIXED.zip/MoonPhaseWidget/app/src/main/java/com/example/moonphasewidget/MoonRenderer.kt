package com.example.moonphasewidget

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import java.util.Random
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Draws the moon artwork. The lit shape is built from exact geometry: a half-circle for the lit limb
 * plus a half-ellipse for the terminator, so the picture always matches the real illuminated fraction.
 */
object MoonRenderer {

    private const val MODE_SOFT = 0     // soft filled craters (storybook)
    private const val MODE_MARIA = 1    // large "seas" blotches, pearly
    private const val MODE_FLAT = 2     // minimal, no surface detail
    private const val MODE_REAL = 3     // seas + ringed craters + sphere shading
    private const val MODE_RINGS = 4    // line-art crater rings
    private const val MODE_DOTS = 5     // stippled surface with golden ring

    private class Style(
        val name: String,
        val lit: Int,
        val dark: Int,
        val tex: Int,
        val rim: Int,
        val glow: Int,
        val mode: Int
    )

    private val STYLES = listOf(
        Style("Lavender storybook", 0xFFF1E8FF.toInt(), 0xFF65558F.toInt(), 0xFFB8A8D9.toInt(), 0xFFFFF8FF.toInt(), 0xFFB9A6FF.toInt(), MODE_SOFT),
        Style("Pearl white", 0xFFF7F7F5.toInt(), 0xFF59616D.toInt(), 0xFFC4C6C4.toInt(), 0xFFFFFFFF.toInt(), 0xFFFFFFFF.toInt(), MODE_MARIA),
        Style("Silver minimal", 0xFFE7EBF0.toInt(), 0xFF525D6B.toInt(), 0xFFB8C0CA.toInt(), 0xFFF9FBFF.toInt(), 0, MODE_FLAT),
        Style("Blue lunar", 0xFFE4F1F6.toInt(), 0xFF435D72.toInt(), 0xFF8EA9BA.toInt(), 0xFFF6FCFF.toInt(), 0xFF7FC8F0.toInt(), MODE_REAL),
        Style("Soft lilac", 0xFFF4EAF2.toInt(), 0xFF79647F.toInt(), 0xFFB79FBF.toInt(), 0xFFFFF8FF.toInt(), 0xFFE2B8E8.toInt(), MODE_RINGS),
        Style("Golden accent", 0xFFFFF0CC.toInt(), 0xFF756044.toInt(), 0xFFD9BD83.toInt(), 0xFFFFE08A.toInt(), 0xFFFFD36B.toInt(), MODE_DOTS)
    )

    val styleNames: List<String> = STYLES.map { it.name }

    // x, y, radius as fractions of the moon radius
    private val CRATERS = arrayOf(
        floatArrayOf(-.30f, -.42f, .12f), floatArrayOf(.20f, -.28f, .18f),
        floatArrayOf(.42f, .08f, .10f), floatArrayOf(-.12f, .18f, .08f),
        floatArrayOf(.18f, .48f, .13f), floatArrayOf(-.42f, .35f, .07f),
        floatArrayOf(.02f, -.02f, .05f)
    )

    // x, y, radiusX, radiusY, rotation (degrees) - rough near-side "seas" layout
    private val MARIA = arrayOf(
        floatArrayOf(-.22f, -.30f, .30f, .24f, 0f),
        floatArrayOf(.18f, -.30f, .16f, .16f, 0f),
        floatArrayOf(.30f, -.02f, .22f, .17f, -20f),
        floatArrayOf(.62f, -.18f, .10f, .08f, 0f),
        floatArrayOf(-.52f, .00f, .20f, .34f, 0f),
        floatArrayOf(-.20f, .45f, .20f, .13f, 0f),
        floatArrayOf(.45f, .30f, .12f, .17f, 20f)
    )

    private fun withAlpha(color: Int, alpha: Int): Int =
        (alpha.coerceIn(0, 255) shl 24) or (color and 0x00FFFFFF)

    private fun darker(c: Int): Int = Color.rgb(
        (Color.red(c) * 0.55f).toInt(),
        (Color.green(c) * 0.55f).toInt(),
        (Color.blue(c) * 0.55f).toInt()
    )

    /**
     * @param illumination lit fraction 0..1
     * @param waxing true: lit limb on the right (northern-hemisphere view); false: on the left
     */
    fun render(illumination: Double, waxing: Boolean, styleIndex: Int, size: Int): Bitmap {
        val st = STYLES[styleIndex.coerceIn(0, STYLES.lastIndex)]
        val k = illumination.coerceIn(0.0, 1.0)
        val out = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(out)
        val cx = size / 2f
        val cy = size / 2f
        val r = size * 0.40f

        // 1. soft glow, stronger when more of the moon is lit
        if (st.glow != 0) {
            val glowAlpha = (30 + 90 * k).toInt()
            val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG)
            glowPaint.shader = RadialGradient(
                cx, cy, r * 1.22f,
                intArrayOf(withAlpha(st.glow, glowAlpha), withAlpha(st.glow, 0)),
                floatArrayOf(0.80f, 1f),
                Shader.TileMode.CLAMP
            )
            canvas.drawCircle(cx, cy, r * 1.22f, glowPaint)
        }

        // 2. dark side of the disc (always visible as a dim sphere)
        val darkLayer = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val dc = Canvas(darkLayer)
        val fill = Paint(Paint.ANTI_ALIAS_FLAG)
        fill.color = st.dark
        dc.drawCircle(cx, cy, r, fill)
        drawTexture(dc, st, cx, cy, r, false)
        canvas.drawBitmap(darkLayer, 0f, 0f, null)
        darkLayer.recycle()

        // 3. lit part, built from exact limb + terminator geometry
        if (k > 0.0004) {
            val litLayer = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
            val lc = Canvas(litLayer)
            fill.color = st.lit
            lc.drawPath(litPath(cx, cy, r, k, waxing), fill)
            drawTexture(lc, st, cx, cy, r, true)
            canvas.drawBitmap(litLayer, 0f, 0f, null)
            litLayer.recycle()
        }

        // 4. rim
        val rim = Paint(Paint.ANTI_ALIAS_FLAG)
        rim.style = Paint.Style.STROKE
        rim.color = withAlpha(st.rim, if (st.mode == MODE_DOTS) 200 else 95)
        rim.strokeWidth = size * (if (st.mode == MODE_DOTS) 0.016f else 0.010f)
        canvas.drawCircle(cx, cy, r, rim)
        if (st.mode == MODE_DOTS) {
            rim.color = withAlpha(st.rim, 70)
            rim.strokeWidth = size * 0.006f
            canvas.drawCircle(cx, cy, r * 1.09f, rim)
        }
        return out
    }

    /**
     * Lit region: half-circle on the lit side, closed by a half-ellipse (the terminator) whose
     * horizontal radius is r * |cos E| = r * |1 - 2k| and which bulges right when 1 - 2k > 0 for a
     * waxing moon (crescent), left for gibbous; mirrored for a waning moon.
     */
    private fun litPath(cx: Float, cy: Float, r: Float, k: Double, waxing: Boolean): Path {
        val sign = if (waxing) 1f else -1f
        val tx = ((1.0 - 2.0 * k) * r).toFloat() * sign      // signed x of the terminator at the equator
        val a = abs(tx).coerceAtLeast(0.5f)
        val limb = RectF(cx - r, cy - r, cx + r, cy + r)
        val term = RectF(cx - a, cy - r, cx + a, cy + r)
        val path = Path()
        path.arcTo(limb, -90f, if (waxing) 180f else -180f, true)   // top -> bottom along the lit limb
        path.arcTo(term, 90f, if (tx > 0f) -180f else 180f, false)  // bottom -> top along the terminator
        path.close()
        return path
    }

    private fun drawTexture(c: Canvas, st: Style, cx: Float, cy: Float, r: Float, lit: Boolean) {
        if (st.mode == MODE_FLAT) return
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        paint.xfermode = PorterDuffXfermode(PorterDuff.Mode.SRC_ATOP)   // only paint where the layer already has pixels
        val color = if (lit) st.tex else darker(st.dark)
        val alpha = if (lit) 170 else 90

        when (st.mode) {
            MODE_SOFT -> {
                paint.color = withAlpha(color, alpha)
                for (cr in CRATERS) c.drawCircle(cx + cr[0] * r, cy + cr[1] * r, cr[2] * r, paint)
            }
            MODE_MARIA, MODE_REAL -> {
                paint.color = withAlpha(color, (alpha * 0.75f).toInt())
                drawMaria(c, paint, cx, cy, r)
                if (st.mode == MODE_REAL) {
                    for (cr in CRATERS) {
                        val px = cx + cr[0] * r
                        val py = cy + cr[1] * r
                        paint.style = Paint.Style.FILL
                        paint.color = withAlpha(color, alpha)
                        c.drawCircle(px, py, cr[2] * r * 0.8f, paint)
                        if (lit) {
                            paint.style = Paint.Style.STROKE
                            paint.strokeWidth = r * 0.02f
                            paint.color = withAlpha(st.rim, 110)
                            c.drawCircle(px, py, cr[2] * r * 0.8f, paint)
                        }
                    }
                    paint.style = Paint.Style.FILL
                }
                // sphere shading toward the limb
                val shade = Paint(Paint.ANTI_ALIAS_FLAG)
                shade.xfermode = PorterDuffXfermode(PorterDuff.Mode.SRC_ATOP)
                shade.shader = RadialGradient(
                    cx - 0.25f * r, cy - 0.25f * r, r * 1.35f,
                    intArrayOf(0x00000000, withAlpha(st.dark, if (lit) 110 else 60)),
                    floatArrayOf(0.45f, 1f),
                    Shader.TileMode.CLAMP
                )
                c.drawCircle(cx, cy, r, shade)
            }
            MODE_RINGS -> {
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = r * 0.04f
                paint.color = withAlpha(color, if (lit) 200 else 110)
                for (cr in CRATERS) c.drawCircle(cx + cr[0] * r, cy + cr[1] * r, cr[2] * r, paint)
            }
            MODE_DOTS -> {
                paint.color = withAlpha(color, if (lit) 190 else 100)
                val rnd = Random(11L)
                for (i in 0 until 55) {
                    val ang = rnd.nextDouble() * 2.0 * PI
                    val dist = sqrt(rnd.nextDouble()) * 0.88
                    val rad = r * (0.012f + 0.03f * rnd.nextFloat())
                    c.drawCircle(cx + (cos(ang) * dist * r).toFloat(), cy + (sin(ang) * dist * r).toFloat(), rad, paint)
                }
                for (i in 0 until 4) {
                    val cr = CRATERS[i]
                    c.drawCircle(cx + cr[0] * r, cy + cr[1] * r, cr[2] * r * 0.7f, paint)
                }
            }
        }
    }

    private fun drawMaria(c: Canvas, paint: Paint, cx: Float, cy: Float, r: Float) {
        paint.style = Paint.Style.FILL
        for (m in MARIA) {
            val px = cx + m[0] * r
            val py = cy + m[1] * r
            c.save()
            c.rotate(m[4], px, py)
            c.drawOval(RectF(px - m[2] * r, py - m[3] * r, px + m[2] * r, py + m[3] * r), paint)
            c.restore()
        }
    }

    /**
     * Transparent star field drawn over the navy widget background. Deterministic, so every style
     * and every refresh shows the identical sky. Stars stay out of the rounded corners.
     */
    fun renderStars(w: Int, h: Int): Bitmap {
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val rnd = Random(20240611L)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        val tints = intArrayOf(0xFFFFFFFF.toInt(), 0xFFCFE0FF.toInt(), 0xFFFFF1D0.toInt())
        var placed = 0
        var guard = 0
        while (placed < 46 && guard < 600) {
            guard++
            val x = ((0.07 + 0.86 * rnd.nextDouble()) * w).toFloat()
            val y = ((0.07 + 0.86 * rnd.nextDouble()) * h).toFloat()
            val roll = rnd.nextInt(100)
            val rad = w * (0.0035f + 0.0065f * rnd.nextFloat())
            val tint = tints[rnd.nextInt(tints.size)]
            val alpha = 110 + rnd.nextInt(146)
            val inCornerX = x < 0.2f * w || x > 0.8f * w
            val inCornerY = y < 0.2f * h || y > 0.8f * h
            if (inCornerX && inCornerY) continue
            paint.style = Paint.Style.FILL
            paint.color = withAlpha(tint, alpha)
            c.drawCircle(x, y, rad, paint)
            if (roll < 12) {   // a few brighter stars get a small sparkle
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = (w * 0.0035f).coerceAtLeast(1f)
                paint.color = withAlpha(tint, 150)
                val len = rad * 3.6f
                c.drawLine(x - len, y, x + len, y, paint)
                c.drawLine(x, y - len, x, y + len, paint)
            }
            placed++
        }
        return bmp
    }
}
