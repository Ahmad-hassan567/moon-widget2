package com.example.moonphasewidget

import java.time.LocalDate
import kotlin.math.acos
import kotlin.math.asin
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.tan

/**
 * Offline sunset estimate (NOAA solar-position algorithm, sun's upper limb, standard refraction).
 * Defaults to Karachi, Pakistan (UTC+5, no DST). This is an astronomical sunset, not a
 * published prayer-time table.
 */
object SunsetTime {
    const val KARACHI_LAT = 24.8607
    const val KARACHI_LON = 67.0011
    const val KARACHI_UTC_OFFSET = 5.0

    private fun deg(r: Double) = Math.toDegrees(r)
    private fun rad(d: Double) = Math.toRadians(d)

    /** Returns declination (deg) and equation of time (minutes) for a Julian Day. */
    private fun solarParams(jd: Double): DoubleArray {
        val t = (jd - 2451545.0) / 36525.0
        val l0 = (280.46646 + t * (36000.76983 + t * 0.0003032)).mod(360.0)
        val m = 357.52911 + t * (35999.05029 - 0.0001537 * t)
        val e = 0.016708634 - t * (0.000042037 + 0.0000001267 * t)
        val c = sin(rad(m)) * (1.914602 - t * (0.004817 + 0.000014 * t)) +
            sin(rad(2.0 * m)) * (0.019993 - 0.000101 * t) +
            sin(rad(3.0 * m)) * 0.000289
        val trueLong = l0 + c
        val omega = 125.04 - 1934.136 * t
        val apparent = trueLong - 0.00569 - 0.00478 * sin(rad(omega))
        val seconds = 21.448 - t * (46.815 + t * (0.00059 - t * 0.001813))
        val obliqueMean = 23.0 + (26.0 + seconds / 60.0) / 60.0
        val oblique = obliqueMean + 0.00256 * cos(rad(omega))
        val declination = deg(asin(sin(rad(oblique)) * sin(rad(apparent))))
        val y = tan(rad(oblique / 2.0)).let { it * it }
        val eqTime = 4.0 * deg(
            y * sin(2.0 * rad(l0)) -
                2.0 * e * sin(rad(m)) +
                4.0 * e * y * sin(rad(m)) * cos(2.0 * rad(l0)) -
                0.5 * y * y * sin(4.0 * rad(l0)) -
                1.25 * e * e * sin(2.0 * rad(m))
        )
        return doubleArrayOf(declination, eqTime)
    }

    private fun hourAngle(latitude: Double, declination: Double): Double? {
        val cosHa = cos(rad(90.833)) / (cos(rad(latitude)) * cos(rad(declination))) -
            tan(rad(latitude)) * tan(rad(declination))
        if (cosHa > 1.0 || cosHa < -1.0) return null
        return deg(acos(cosHa))
    }

    /**
     * Local sunset time in decimal hours (0..24) for [date] at the given place.
     * Falls back to 18.0 if the sun never sets (not possible at Pakistani latitudes).
     */
    fun sunsetHour(
        date: LocalDate,
        latitude: Double = KARACHI_LAT,
        longitude: Double = KARACHI_LON,
        utcOffset: Double = KARACHI_UTC_OFFSET
    ): Double {
        val jd0 = date.toEpochDay() + 2440587.5            // 0h UT of the date
        var p = solarParams(jd0 + 0.5 - utcOffset / 24.0)
        var ha = hourAngle(latitude, p[0]) ?: return 18.0
        var utcMinutes = 720.0 - 4.0 * (longitude - ha) - p[1]
        // second pass at the time found, for better accuracy
        p = solarParams(jd0 + utcMinutes / 1440.0)
        ha = hourAngle(latitude, p[0]) ?: return 18.0
        utcMinutes = 720.0 - 4.0 * (longitude - ha) - p[1]
        return (utcMinutes / 60.0 + utcOffset).mod(24.0)
    }
}
