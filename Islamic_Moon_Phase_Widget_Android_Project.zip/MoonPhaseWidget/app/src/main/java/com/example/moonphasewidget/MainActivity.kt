package com.example.moonphasewidget

import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.os.Bundle
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("moon_prefs", MODE_PRIVATE)
        val styles = MoonRenderer.styleNames
        val pad = (20 * resources.displayMetrics.density).toInt()
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(pad, pad, pad, pad)
            setBackgroundColor(android.graphics.Color.rgb(11,18,32))
        }
        val title = TextView(this).apply {
            text = "🌙  Islamic Moon"
            textSize = 25f
            setTextColor(0xFFF4EFFF.toInt())
            gravity = Gravity.CENTER
        }
        val intro = TextView(this).apply {
            text = "Choose your moon artwork"
            textSize = 14f
            setTextColor(0xFFAAB8D0.toInt())
            setPadding(0, pad/2, 0, pad)
        }
        val preview = ImageView(this).apply {
            setImageBitmap(MoonRenderer.render(0.5, prefs.getInt("style", 0), 220))
            layoutParams = LinearLayout.LayoutParams(180,180)
        }
        val spinner = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, styles)
            setSelection(prefs.getInt("style", 0))
        }
        spinner.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: android.view.View?, position: Int, id: Long) {
                preview.setImageBitmap(MoonRenderer.render(0.5, position, 220))
                prefs.edit().putInt("style", position).apply()
            }
        }
        val offsetLabel = TextView(this).apply {
            text = "Pakistan moon-sighting adjustment"
            textSize = 14f
            setTextColor(0xFFF4EFFF.toInt())
            setPadding(0, pad, 0, 4)
        }
        val offsetSpinner = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                listOf("−1 day", "No adjustment", "+1 day"))
            setSelection(prefs.getInt("offset", 1).coerceIn(0,2))
        }
        offsetSpinner.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: android.view.View?, position: Int, id: Long) {
                prefs.edit().putInt("offset", position - 1).apply()
            }
        }
        val note = TextView(this).apply {
            text = "The widget uses an astronomical moon phase and an estimated Karachi Maghrib time. Official Ruet-e-Hilal announcements can differ; adjust the Hijri date by one day when needed."
            textSize = 12f
            setTextColor(0xFFAAB8D0.toInt())
            setPadding(0, pad, 0, pad)
        }
        val apply = Button(this).apply {
            text = "Apply to Home Screen Widget"
            setOnClickListener {
                val manager = AppWidgetManager.getInstance(this@MainActivity)
                val ids = manager.getAppWidgetIds(ComponentName(this@MainActivity, MoonWidgetProvider::class.java))
                ids.forEach { MoonWidgetProvider.update(this@MainActivity, manager, it) }
                Toast.makeText(this@MainActivity, "Widget updated", Toast.LENGTH_SHORT).show()
            }
        }
        layout.addView(title); layout.addView(intro); layout.addView(preview)
        layout.addView(spinner, LinearLayout.LayoutParams(-1, -2))
        layout.addView(offsetLabel); layout.addView(offsetSpinner, LinearLayout.LayoutParams(-1, -2))
        layout.addView(note); layout.addView(apply, LinearLayout.LayoutParams(-1, -2))
        setContentView(ScrollView(this).apply { addView(layout) })
    }
}
