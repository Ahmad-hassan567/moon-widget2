package com.example.moonphasewidget

import java.time.LocalDate
import kotlin.math.*

object SunsetTime {
    // Default city: Karachi, Pakistan. This is an astronomical sunset estimate,
    // not an official prayer-time timetable.
    fun localSunsetHour(date: LocalDate, latitude: Double = 24.8607, longitude: Double = 67.0011, utcOffset: Double = 5.0): Double {
        val n = date.dayOfYear.toDouble()
        val lngHour = longitude / 15.0
        val t = n + ((18.0 - lngHour) / 24.0)
        val m = 0.9856 * t - 3.289
        var l = m + 1.916 * sin(Math.toRadians(m)) +
            0.020 * sin(Math.toRadians(2 * m)) + 282.634
        l = (l % 360.0 + 360.0) % 360.0
        var ra = Math.toDegrees(atan(0.91764 * tan(Math.toRadians(l))))
        ra = (ra % 360.0 + 360.0) % 360.0
        val lQuadrant = floor(l / 90.0) * 90.0
        val raQuadrant = floor(ra / 90.0) * 90.0
        ra = (ra + lQuadrant - raQuadrant) / 15.0
        val sinDec = 0.39782 * sin(Math.toRadians(l))
        val cosDec = cos(asin(sinDec))
        val cosH = (cos(Math.toRadians(90.833)) - sinDec * sin(Math.toRadians(latitude))) /
            (cosDec * cos(Math.toRadians(latitude)))
        if (cosH !in -1.0..1.0) return 18.0
        val h = acos(cosH) / 15.0
        val localMeanTime = h + ra - 0.06571 * t - 6.622
        val utc = (localMeanTime - lngHour + 24.0) % 24.0
        return (utc + utcOffset) % 24.0
    }
}
