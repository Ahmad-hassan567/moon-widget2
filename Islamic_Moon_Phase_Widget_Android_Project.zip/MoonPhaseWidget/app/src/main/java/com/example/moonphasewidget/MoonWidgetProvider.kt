package com.example.moonphasewidget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import java.time.LocalDate
import java.time.ZoneId
import java.time.chrono.HijrahDate
import java.time.format.TextStyle
import java.util.Locale

class MoonWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { update(context, manager, it) }
    }
    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == Intent.ACTION_DATE_CHANGED ||
            intent.action == Intent.ACTION_TIME_CHANGED ||
            intent.action == Intent.ACTION_TIMEZONE_CHANGED) {
            val manager = AppWidgetManager.getInstance(context)
            manager.getAppWidgetIds(ComponentName(context, MoonWidgetProvider::class.java))
                .forEach { update(context, manager, it) }
        }
    }
    companion object {
        fun update(context: Context, manager: AppWidgetManager, id: Int) {
            val prefs = context.getSharedPreferences("moon_prefs", Context.MODE_PRIVATE)
            val style = prefs.getInt("style", 0)
            val offset = prefs.getInt("offset", 0)
            val now = java.time.ZonedDateTime.now(ZoneId.of("Asia/Karachi"))
            val today = now.toLocalDate()
            val sunsetHour = SunsetTime.localSunsetHour(today)
            val nowHour = now.hour + now.minute / 60.0
            val date = if (nowHour >= sunsetHour) today.plusDays(1) else today
            val hijri = HijrahDate.from(LocalDate.from(date)).plus(offset.toLong(), java.time.temporal.ChronoUnit.DAYS)
            val day = hijri.get(java.time.temporal.ChronoField.DAY_OF_MONTH)
            val month = hijri.get(java.time.temporal.ChronoField.MONTH_OF_YEAR)
            val year = hijri.get(java.time.temporal.ChronoField.YEAR)
            val monthName = hijri.get(java.time.temporal.ChronoField.MONTH_OF_YEAR)
            val names = listOf("Muharram","Safar","Rabi-ul-Awwal","Rabi-us-Sani","Jumada-ul-Ula","Jumada-us-Sania","Rajab","Shaban","Ramadan","Shawwal","Dhul-Qadah","Dhul-Hijjah")
            val phase = MoonMath.phase(date)
            val phaseName = MoonMath.phaseName(phase)
            val hijriText = "$day ${names[(monthName-1).coerceIn(0,11)]} $year"
            val views = RemoteViews(context.packageName, R.layout.moon_widget)
            views.setImageViewBitmap(R.id.moon_image, MoonRenderer.render(phase, style, 240))
            views.setTextViewText(R.id.hijri_date, hijriText)
            views.setTextViewText(R.id.phase_name, phaseName)
            val open = PendingIntent.getActivity(context, 0, Intent(context, MainActivity::class.java),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            views.setOnClickPendingIntent(R.id.widget_root, open)
            manager.updateAppWidget(id, views)
        }
    }
}
