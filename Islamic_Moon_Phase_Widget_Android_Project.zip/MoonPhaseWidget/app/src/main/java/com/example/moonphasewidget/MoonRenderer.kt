package com.example.moonphasewidget

import android.graphics.*
import kotlin.math.*

object MoonRenderer {
    val styleNames = listOf(
        "Lavender storybook", "Pearl white", "Silver minimal", "Blue lunar", "Soft lilac", "Golden accent"
    )
    private data class Palette(val light: Int, val dark: Int, val crater: Int, val edge: Int)
    private val palettes = listOf(
        Palette(0xFFF1E8FF.toInt(),0xFF65558F.toInt(),0xFFB8A8D9.toInt(),0xFFFFF8FF.toInt()),
        Palette(0xFFF7F7F5.toInt(),0xFF59616D.toInt(),0xFFD8D9D8.toInt(),0xFFFFFFFF.toInt()),
        Palette(0xFFE7EBF0.toInt(),0xFF525D6B.toInt(),0xFFB8C0CA.toInt(),0xFFF9FBFF.toInt()),
        Palette(0xFFE4F1F6.toInt(),0xFF435D72.toInt(),0xFF9DB6C5.toInt(),0xFFF6FCFF.toInt()),
        Palette(0xFFF4EAF2.toInt(),0xFF79647F.toInt(),0xFFCDB8D1.toInt(),0xFFFFF8FF.toInt()),
        Palette(0xFFFFF0CC.toInt(),0xFF756044.toInt(),0xFFD9BD83.toInt(),0xFFFFF7E5.toInt())
    )
    fun render(phase: Double, style: Int, size: Int): Bitmap {
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val p = palettes[style.coerceIn(0, palettes.lastIndex)]
        val cx=size/2f; val cy=size/2f; val r=size*0.43f
        val paint=Paint(Paint.ANTI_ALIAS_FLAG)
        paint.color=p.dark; c.drawCircle(cx,cy,r,paint)
        val lit = (1.0 - cos(2*PI*phase))/2.0
        val waxing = phase < 0.5
        val term = ((if (waxing) cos(2*PI*phase) else -cos(2*PI*phase))*r).toFloat()
        val path=Path()
        if (waxing) {
            path.moveTo(cx,cy-r)
            path.cubicTo(cx+term,cy-r*0.55f,cx+term,cy+r*0.55f,cx,cy+r)
            path.cubicTo(cx+r*0.58f,cy+r*0.82f,cx+r,cy+r*0.35f,cx+r,cy)
            path.cubicTo(cx+r,cy-r*0.35f,cx+r*0.58f,cy-r*0.82f,cx,cy-r)
        } else {
            path.moveTo(cx,cy-r)
            path.cubicTo(cx+term,cy-r*0.55f,cx+term,cy+r*0.55f,cx,cy+r)
            path.cubicTo(cx-r*0.58f,cy+r*0.82f,cx-r,cy+r*0.35f,cx-r,cy)
            path.cubicTo(cx-r,cy-r*0.35f,cx-r*0.58f,cy-r*0.82f,cx,cy-r)
        }
        paint.color=p.light
        c.save()
        val clip=Path().apply { addCircle(cx,cy,r,Path.Direction.CW) }
        c.clipPath(clip); c.drawPath(path,paint)
        // Consistent illustrated crater details, clipped to the lunar disc.
        val craters = arrayOf(
            floatArrayOf(-.30f,-.42f,.12f), floatArrayOf(.20f,-.28f,.18f),
            floatArrayOf(.42f,.08f,.10f), floatArrayOf(-.12f,.18f,.08f),
            floatArrayOf(.18f,.48f,.13f), floatArrayOf(-.42f,.35f,.07f),
            floatArrayOf(.02f,-.02f,.05f)
        )
        val craterPaint=Paint(Paint.ANTI_ALIAS_FLAG).apply { color=p.crater; alpha=150 }
        craters.forEach { a -> c.drawCircle(cx+a[0]*r,cy+a[1]*r,a[2]*r,craterPaint) }
        val highlight=Paint(Paint.ANTI_ALIAS_FLAG).apply { color=p.edge; style=Paint.Style.STROKE; strokeWidth=size*.012f }
        c.drawCircle(cx,cy,r,highlight)
        c.restore()
        return bmp
    }
}
