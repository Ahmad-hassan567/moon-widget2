package com.example.moonphasewidget

import java.time.LocalDate
import kotlin.math.*

object MoonMath {
    // Meeus-style mean synodic phase approximation; sufficient for a visual widget.
    fun phase(date: LocalDate): Double {
        val jd = date.toEpochDay().toDouble() + 2440587.5
        val days = jd - 2451550.1
        return ((days / 29.530588853) % 1.0 + 1.0) % 1.0
    }
    fun phaseName(p: Double): String = when {
        p < 0.03 || p >= 0.97 -> "New Moon"
        p < 0.22 -> "Waxing Crescent"
        p < 0.28 -> "First Quarter"
        p < 0.47 -> "Waxing Gibbous"
        p < 0.53 -> "Full Moon"
        p < 0.72 -> "Waning Gibbous"
        p < 0.78 -> "Last Quarter"
        else -> "Waning Crescent"
    }
}
