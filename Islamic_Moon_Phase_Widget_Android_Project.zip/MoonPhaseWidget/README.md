# Islamic Moon Phase Widget (Android)

A compact 2×2 Android home-screen widget with a shared midnight-navy background, six selectable illustrated moon palettes, a Hijri date, and a phase label.

## Build the APK
1. Install Android Studio (Giraffe or newer) with Android SDK Platform 35.
2. Open this `MoonPhaseWidget` folder in Android Studio.
3. Allow Gradle sync to finish.
4. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Install the generated APK on the Android phone.
6. Open **Moon Phase** once, choose an artwork style, then tap **Apply to Home Screen Widget**.
7. Long-press the home screen, choose **Widgets**, find **Islamic Moon**, and place the 2×2 widget.

## Notes
- No network permission or internet connection is required.
- Moon artwork is generated locally; the same navy background is used for every style.
- The phase is an astronomical approximation for display, not an observation of the visible crescent.
- Hijri date uses Android's built-in Hijrah calendar with a manual −1/0/+1 day adjustment. The default is no adjustment.
- Hijri date rolls over at an astronomical sunset estimate for Karachi (default coordinates), rather than at midnight. This is not an official prayer-time timetable; adjust the Hijri date by one day when the official sighting differs.
- Pakistan's official Ruet-e-Hilal announcement can differ from calculated Hijri dates. Use the adjustment setting to align it.
